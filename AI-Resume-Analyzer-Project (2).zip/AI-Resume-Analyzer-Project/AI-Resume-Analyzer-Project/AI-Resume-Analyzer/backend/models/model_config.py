# Keep model configuration here as the project grows.
BASELINE_MODEL = "tfidf_cosine_similarity"
OPTIONAL_MODEL = "sentence_transformer"
