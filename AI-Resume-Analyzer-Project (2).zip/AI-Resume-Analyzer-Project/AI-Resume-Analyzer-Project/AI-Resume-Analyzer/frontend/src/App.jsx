import React, { useEffect, useState } from "react";

const pages = ["home", "analyze", "history", "about"];

function PageNav({ currentPage, onNavigate }) {
  return (
    <nav className="page-nav" aria-label="Main navigation">
      {pages.map((page) => (
        <button
          className={currentPage === page ? "active" : ""}
          key={page}
          type="button"
          onClick={() => onNavigate(page)}
        >
          {page === "analyze" ? "Analyze Resume" : page[0].toUpperCase() + page.slice(1)}
        </button>
      ))}
    </nav>
  );
}

function SimplePage({ currentPage, onNavigate, children }) {
  return (
    <main className="app-shell">
      <header className="topbar">
        <button className="brand" type="button" onClick={() => onNavigate("home")}>
          <span className="brand-mark">AI</span>
          <span>Resume / Match</span>
        </button>
        <PageNav currentPage={currentPage} onNavigate={onNavigate} />
      </header>
      {children}
      <footer><span>AI RESUME ANALYZER</span><span>Find the signal in your story.</span></footer>
    </main>
  );
}

export default function App() {
  const [currentPage, setCurrentPage] = useState(window.location.hash.slice(1) || "home");
  const [resume, setResume] = useState(null);
  const [jobDescription, setJobDescription] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const handleHashChange = () => setCurrentPage(window.location.hash.slice(1) || "home");
    window.addEventListener("popstate", handleHashChange);
    window.addEventListener("hashchange", handleHashChange);
    return () => {
      window.removeEventListener("popstate", handleHashChange);
      window.removeEventListener("hashchange", handleHashChange);
    };
  }, []);

  function selectResume(file) {
    if (!file) return;
    if (file.type !== "application/pdf") {
      setError("Please choose a PDF resume.");
      return;
    }
    setResume(file);
    setError("");
  }

  async function analyzeResume(event) {
    event.preventDefault();
    setError("");
    setResult(null);

    if (!resume || !jobDescription.trim()) {
      setError("Please upload a PDF resume and enter a job description.");
      return;
    }

    const formData = new FormData();
    formData.append("resume", resume);
    formData.append("job_description", jobDescription);

    try {
      setIsAnalyzing(true);
      const response = await fetch("http://127.0.0.1:5001/api/analyze", {
        method: "POST",
        body: formData
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Analysis failed");
      setResult(data);
      setHistory((previous) => [
        {
          id: Date.now(),
          fileName: resume.name,
          score: Math.round(Number(data.similarity_score)),
          skills: (data.matched_skills || []).length,
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
        },
        ...previous
      ].slice(0, 3));
    } catch (err) {
      setError(err.message);
    } finally {
      setIsAnalyzing(false);
    }
  }

  const score = result ? Math.round(Number(result.similarity_score)) : 0;
  const matchedSkills = result?.matched_skills || [];
  const missingSkills = result?.missing_skills || [];
  const totalSkills = matchedSkills.length + missingSkills.length;
  const matchCoverage = totalSkills ? Math.round((matchedSkills.length / totalSkills) * 100) : 0;

  function navigate(page) {
    const nextPage = pages.includes(page) ? page : "home";
    window.history.pushState({}, "", `#${nextPage}`);
    setCurrentPage(nextPage);
  }

  function printReport() {
    window.print();
  }

  if (currentPage === "home") {
    return (
      <SimplePage currentPage={currentPage} onNavigate={navigate}>
        <section className="page-hero home-page">
          <p className="eyebrow">Career intelligence</p>
          <h1>Make your next application <em>count.</em></h1>
          <p className="hero-text">Compare your experience to any role in seconds and discover the strengths that make you stand out.</p>
          <button className="analyze-button page-cta" type="button" onClick={() => navigate("analyze")}>
            <span>Start analyzing your resume</span><span className="button-arrow">↗</span>
          </button>
        </section>
      </SimplePage>
    );
  }

  if (currentPage === "about") {
    return (
      <SimplePage currentPage={currentPage} onNavigate={navigate}>
        <section className="page-hero">
          <p className="eyebrow">About the workspace</p>
          <h1>Find the signal in your <em>story.</em></h1>
          <p className="hero-text">AI Resume Analyzer compares your resume with a job description, highlights matching skills, and shows areas worth developing next.</p>
        </section>
      </SimplePage>
    );
  }

  if (currentPage === "history") {
    return (
      <SimplePage currentPage={currentPage} onNavigate={navigate}>
        <section className="history-section standalone-history">
          <div className="history-heading">
            <div><p className="eyebrow">Workspace memory</p><h2>Recent analyses</h2></div>
            <span className="history-caption">Stored locally in this session</span>
          </div>
          {history.length ? (
            <div className="history-list">
              {history.map((item) => (
                <div className="history-item" key={item.id}>
                  <span className="history-file">PDF</span>
                  <span className="history-name">{item.fileName}</span>
                  <span className="history-skills">{item.skills} matched skills</span>
                  <strong className="history-score">{item.score}%</strong>
                  <span className="history-time">{item.time}</span>
                </div>
              ))}
            </div>
          ) : <div className="history-empty">Your completed comparisons will appear here for quick reference.</div>}
        </section>
      </SimplePage>
    );
  }

  return (
    <main className="app-shell">
      <header className="topbar">
        <button className="brand" type="button" onClick={() => navigate("home")} aria-label="AI Resume Analyzer home">
          <span className="brand-mark">AI</span>
          <span>Resume / Match</span>
        </button>
        <PageNav currentPage={currentPage} onNavigate={navigate} />
      </header>

      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">Career intelligence · 01</p>
          <h1>Make your next application <em>count.</em></h1>
          <p className="hero-text">Compare your experience to any role in seconds. Get a focused read on your strongest matches and the skills worth sharpening next.</p>
          <div className="hero-detail">
            <span className="detail-line" />
            <span>Private by design. Your resume is only used for this analysis.</span>
          </div>
        </div>
        <div className="hero-stat" aria-label="Workflow steps">
          <span className="stat-number">02</span>
          <span className="stat-label">Inputs to a clearer<br />career direction</span>
        </div>
      </section>

      <form onSubmit={analyzeResume} className="workspace-grid">
        <section className="input-panel">
          <div className="section-heading">
            <div>
              <p className="eyebrow">Start here</p>
              <h2>Build your match</h2>
            </div>
            <span className="step-count">01 / 02</span>
          </div>

          <div
            className={`upload-zone ${isDragging ? "is-dragging" : ""} ${resume ? "has-file" : ""}`}
            onDragOver={(event) => { event.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(event) => { event.preventDefault(); setIsDragging(false); selectResume(event.dataTransfer.files[0]); }}
          >
            <input id="resume-upload" type="file" accept="application/pdf,.pdf" onChange={(event) => selectResume(event.target.files[0])} />
            <label htmlFor="resume-upload" className="upload-label">
              <span className="upload-icon">↑</span>
              <span className="upload-title">{resume ? resume.name : "Drop your resume here"}</span>
              <span className="upload-subtitle">{resume ? `${(resume.size / 1024 / 1024).toFixed(2)} MB · PDF ready to analyze` : "or click to browse · PDF only"}</span>
            </label>
          </div>

          <div className="field-heading">
            <label htmlFor="job-description">Job description</label>
            <span>{jobDescription.length} characters</span>
          </div>
          <textarea
            id="job-description"
            rows="9"
            placeholder="Paste the role description, responsibilities, and requirements..."
            value={jobDescription}
            onChange={(event) => setJobDescription(event.target.value)}
          />

          {error && <p className="error" role="alert">{error}</p>}

          <button className="analyze-button" type="submit" disabled={isAnalyzing}>
            <span>{isAnalyzing ? "Reading your match..." : "Analyze compatibility"}</span>
            <span className="button-arrow">↗</span>
          </button>
        </section>

        <aside className={`result-panel ${result ? "result-ready" : ""}`}>
          {!result ? (
            <div className="empty-result">
              <span className="result-index">02</span>
              <div className="empty-orbit"><span /></div>
              <p className="eyebrow">Your readout</p>
              <h2>Clarity is<br /><em>closer</em> than you think.</h2>
              <p>Upload a resume and add a role description to reveal your compatibility score, matched strengths, and next steps.</p>
            </div>
          ) : (
            <div className="result-content">
              <div className="result-header">
                <div>
                  <p className="eyebrow">Your readout</p>
                  <h2>Role compatibility</h2>
                </div>
                <div className="result-actions">
                  <button className="print-button" type="button" onClick={printReport} aria-label="Print analysis report">↗</button>
                  <span className="result-check">✓</span>
                </div>
              </div>
              <div className="score-row">
                <div className="score-ring" style={{ "--score": `${score * 3.6}deg` }}><strong>{score}<small>%</small></strong></div>
                <div><span className="score-label">Overall match</span><p>{result.note}</p></div>
              </div>
              <div className="breakdown-block">
                <div className="breakdown-heading"><span>Signal breakdown</span><strong>{matchCoverage}% coverage</strong></div>
                <div className="meter"><span style={{ width: `${matchCoverage}%` }} /></div>
                <div className="breakdown-legend"><span><i className="legend-match" /> Skill overlap</span><span><i className="legend-gap" /> Development gaps</span></div>
              </div>
              <div className="skill-block">
                <div className="skill-heading"><span>Matched skills</span><strong>{matchedSkills.length}</strong></div>
                <div className="chips">{matchedSkills.length ? matchedSkills.map((skill) => <span className="chip matched" key={skill}>{skill}</span>) : <span className="muted">None detected</span>}</div>
              </div>
              <div className="skill-block missing-block">
                <div className="skill-heading"><span>Worth developing</span><strong>{missingSkills.length}</strong></div>
                <div className="chips">{missingSkills.length ? missingSkills.map((skill) => <span className="chip" key={skill}>{skill}</span>) : <span className="muted">No gaps detected</span>}</div>
              </div>
            </div>
          )}
        </aside>
      </form>

      <section className="history-section">
        <div className="history-heading">
          <div><p className="eyebrow">Workspace memory</p><h2>Recent analyses</h2></div>
          <span className="history-caption">Stored locally in this session</span>
        </div>
        {history.length ? (
          <div className="history-list">
            {history.map((item) => (
              <div className="history-item" key={item.id}>
                <span className="history-file">PDF</span>
                <span className="history-name">{item.fileName}</span>
                <span className="history-skills">{item.skills} matched skills</span>
                <strong className="history-score">{item.score}%</strong>
                <span className="history-time">{item.time}</span>
              </div>
            ))}
          </div>
        ) : <div className="history-empty">Your completed comparisons will appear here for quick reference.</div>}
      </section>

      <footer><span>AI RESUME ANALYZER</span><span>Find the signal in your story.</span></footer>
    </main>
  );
}
