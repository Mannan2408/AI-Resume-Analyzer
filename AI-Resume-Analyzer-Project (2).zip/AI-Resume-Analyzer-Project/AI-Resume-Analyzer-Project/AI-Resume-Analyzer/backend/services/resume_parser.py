import fitz  # PyMuPDF

def extract_text_from_pdf(file_storage):
    file_bytes = file_storage.read()
    document = fitz.open(stream=file_bytes, filetype="pdf")
    text = []

    for page in document:
        text.append(page.get_text())

    document.close()
    return "\n".join(text).strip()
