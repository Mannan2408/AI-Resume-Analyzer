import re

DEFAULT_SKILLS = [
    "python", "java", "c++", "javascript", "react", "html", "css",
    "flask", "fastapi", "sql", "machine learning", "deep learning",
    "nlp", "git", "docker", "aws", "pandas", "numpy"
]

def extract_skills(text: str, skills=None):
    skills = skills or DEFAULT_SKILLS
    lowered = text.lower()
    return sorted({
        skill for skill in skills
        if re.search(rf"(?<!\w){re.escape(skill.lower())}(?!\w)", lowered)
    })
