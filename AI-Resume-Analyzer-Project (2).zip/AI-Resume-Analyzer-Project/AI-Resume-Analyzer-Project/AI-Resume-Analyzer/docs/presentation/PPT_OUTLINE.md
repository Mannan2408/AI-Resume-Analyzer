# PPT Outline

1. Title Slide
2. Team Members
3. Problem Statement
4. Motivation
5. Objectives
6. Existing System
7. Proposed System
8. System Architecture
9. Technologies Used
10. Dataset
11. AI/ML Methodology
12. Demo Screenshots
13. Results
14. Limitations
15. Future Scope
16. Conclusion
