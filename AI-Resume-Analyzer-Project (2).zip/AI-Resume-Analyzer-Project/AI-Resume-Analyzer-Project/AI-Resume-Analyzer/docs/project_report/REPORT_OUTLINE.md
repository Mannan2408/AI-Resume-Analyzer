# Project Report Outline

1. Abstract
2. Introduction
3. Problem Statement
4. Objectives
5. Literature Review
6. Proposed Methodology
7. System Architecture
8. Dataset Description
9. NLP Preprocessing
10. TF-IDF and Cosine Similarity
11. Skill Extraction
12. System Implementation
13. Results and Evaluation
14. Limitations and Ethical Considerations
15. Future Scope
16. Conclusion
17. References
