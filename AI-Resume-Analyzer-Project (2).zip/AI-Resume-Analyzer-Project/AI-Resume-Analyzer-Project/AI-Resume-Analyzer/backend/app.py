from flask import Flask, request, jsonify
from flask_cors import CORS
from services.resume_parser import extract_text_from_pdf
from services.matching_model import calculate_similarity

app = Flask(__name__)
CORS(app)

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "message": "AI Resume Analyzer backend is running"})

@app.post("/api/analyze")
def analyze():
    if "resume" not in request.files:
        return jsonify({"error": "Resume PDF is required"}), 400

    resume_file = request.files["resume"]
    job_description = request.form.get("job_description", "").strip()

    if not job_description:
        return jsonify({"error": "Job description is required"}), 400

    try:
        resume_text = extract_text_from_pdf(resume_file)
        result = calculate_similarity(resume_text, job_description)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

if __name__ == "__main__":
    app.run(debug=True, port=5000)
