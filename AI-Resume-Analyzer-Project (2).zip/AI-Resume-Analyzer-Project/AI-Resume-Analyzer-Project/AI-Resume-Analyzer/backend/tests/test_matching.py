from services.matching_model import calculate_similarity

def test_matching_returns_score():
    result = calculate_similarity(
        "Python developer with Flask and SQL",
        "Looking for Python and Flask developer"
    )
    assert 0 <= result["similarity_score"] <= 100
    assert "python" in result["matched_skills"]


def test_matching_rewards_required_skill_coverage():
    strong_match = calculate_similarity(
        "Senior Python Flask developer with SQL and Docker",
        "Looking for Python Flask developer with SQL"
    )
    weak_match = calculate_similarity(
        "Graphic designer with Photoshop experience",
        "Looking for Python Flask developer with SQL"
    )

    assert strong_match["similarity_score"] > 70
    assert strong_match["similarity_score"] > weak_match["similarity_score"]


def test_skill_matching_does_not_match_java_inside_javascript():
    result = calculate_similarity(
        "Frontend developer with JavaScript and React",
        "Looking for Java developer"
    )

    assert "java" not in result["matched_skills"]


def test_generic_job_terms_are_scored_without_known_skills():
    result = calculate_similarity(
        "Backend engineer building APIs and services",
        "Looking for a backend engineer"
    )

    assert result["similarity_score"] > 0
