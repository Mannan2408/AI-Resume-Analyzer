import re

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from services.skill_extractor import extract_skills
from services.text_preprocessing import clean_text

def calculate_similarity(resume_text: str, job_description: str):
    resume_clean = clean_text(resume_text)
    job_clean = clean_text(job_description)

    if not resume_clean:
        raise ValueError("No readable text was found in the uploaded resume PDF")
    if not job_clean:
        raise ValueError("Job description cannot be empty")

    vectorizer = TfidfVectorizer(stop_words="english")
    vectors = vectorizer.fit_transform([resume_clean, job_clean])
    text_similarity = float(cosine_similarity(vectors[0:1], vectors[1:2])[0][0])

    resume_skills = set(extract_skills(resume_text))
    job_skills = set(extract_skills(job_description))
    missing_skills = sorted(job_skills - resume_skills)
    matched_skills = sorted(resume_skills & job_skills)

    resume_words = set(re.findall(r"\b[a-z][a-z+#.-]{2,}\b", resume_clean))
    job_words = set(re.findall(r"\b[a-z][a-z+#.-]{2,}\b", job_clean))
    stop_words = set(TfidfVectorizer(stop_words="english").get_stop_words() or ())
    meaningful_job_words = job_words - stop_words
    keyword_coverage = (
        len(resume_words & meaningful_job_words) / len(meaningful_job_words)
        if meaningful_job_words else 0
    )

    # CVs are longer than job descriptions and often use different wording.
    # Required-skill coverage is strongest, with keyword and TF-IDF signals as
    # fallbacks for skills outside the built-in dictionary.
    skill_coverage = len(matched_skills) / len(job_skills) if job_skills else 0
    if job_skills:
        similarity = (skill_coverage * 0.55) + (keyword_coverage * 0.15) + (text_similarity * 0.3)
    else:
        similarity = (keyword_coverage * 0.7) + (text_similarity * 0.3)

    return {
        "similarity_score": round(similarity * 100, 2),
        "matched_skills": matched_skills,
        "missing_skills": missing_skills,
        "resume_skills": sorted(resume_skills),
        "job_skills": sorted(job_skills),
        "note": "This is an experimental text-matching indicator, not a hiring prediction."
    }
